/** @type {import('next').NextConfig} */
const nextConfig = {
  output: 'export',
  images: {
    unoptimized: true,
    remotePatterns: [
      {
        protocol: 'https',
        hostname: '**.vercel.app',
      },
      {
        protocol: 'https',
        hostname: '**.neynar.com',
      },
      {
        protocol: 'https',
        hostname: '**.onrender.com',
      },
    ],
  },
  // Disable features that require server during build
  eslint: {
    ignoreDuringBuilds: true,
  },
  typescript: {
    ignoreBuildErrors: true,
  },
  // Memory optimization settings
  swcMinify: false, // Use legacy minification to reduce memory
  modularizeImports: {
    // Optimize imports to reduce bundle size
    lodash: {
      transform: 'lodash/{{member}}',
    },
  },
}

module.exports = nextConfig
